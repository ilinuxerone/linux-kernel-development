#!/usr/bin/perl


#main
$numArgs = $#ARGV + 1;
if ($numArgs < 1 ) {
	printf ("Usage: collect_rb.pl <filename> \n");
	exit (1);
}
$logfile = $ARGV[0];

system ("rm $logfile 2>/dev/null");

while (true) {
	&do_work;
	system (sleep(1));
}

sub do_work
{
	my($path) = "/sys/class/scsi_host";
	my(@line);
	my($shost);
	my($proc_name);

	chdir($path);
	@line = `ls -1`;
	foreach (@line) {
		chomp;
		$shost = join("/", $path, $_);
		$proc_name = "";
		$proc_name = `cat $shost/proc_name`;
		chomp $proc_name;
		&process_shost($shost, $_) if ($proc_name eq 'mptsas');
	}
}

sub process_shost
{
	my($shost_path, $shost_name) = @_;
	my($fault);

	chdir($shost_path);

	$date = `date`;
	chomp($date);

	open(FH, "<fault") or die $!;
	close(FH);

	$fault=`cat fault`;
	chomp $fault;

	printf ("$date: $shost_name: fault = $fault\n");

	if ( $fault eq '2') {
		&process_fault($shost_path);
		system("echo 0 > fault");
		die ("Done processing fault, exiting this script ring buffer
is in $logfile");
	}
}

sub process_fault
{
	my($shost_path) = @_;
	my($ring_buffer_size);
	my($offset);
	my($page_size);

	chdir($shost_path);

	$ring_buffer_size=`cat ring_buffer_size`;
	$page_size = 4096;
	$offset = 0;

	printf ("ring_buffer_size = $ring_buffer_size\n");

	while ($offset < $ring_buffer_size) {
		printf ("offset = $offset\n");
		system (`echo $offset > ring_buffer` );
		open(FH, "<ring_buffer");
		@ring_buffer = <FH>;
		close(FH);
		open(LOGFILE, ">>$logfile");
		foreach (@ring_buffer) {
			print LOGFILE;
		}
		close(LOGFILE);
		$offset += $page_size;
	}

}

